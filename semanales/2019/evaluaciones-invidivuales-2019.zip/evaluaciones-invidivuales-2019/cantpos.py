# Devuelve la cantidad de elementos positivos en la lista L de enteros.
def cantpos(L):
  ##COMPLETAR##

  
print(cantpos([1,2,3,4]))      # debe imprimir 4
print(cantpos([-1,2,-3,-4]))   # debe imprimir 1
print(cantpos([-1,-2,-3,-4]))  # debe imprimir 0
print(cantpos([]))             # debe imprimir 0

