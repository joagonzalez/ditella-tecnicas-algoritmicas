# Devuelve la suma de los elementos positivos de la lista L de enteros.
def sumarpos(L):
  ##COMPLETAR##

  
print(sumarpos([1,2,3,4]))      # debe imprimir 10
print(sumarpos([-1,2,-3,-4]))   # debe imprimir 2
print(sumarpos([-1,-2,-3,-4]))  # debe imprimir 0
print(sumarpos([]))             # debe imprimir 0

